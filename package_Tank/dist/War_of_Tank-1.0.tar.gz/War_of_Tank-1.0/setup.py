from distutils.core import setup

setup(name="War_of_Tank", version="1.0", description="test_version", author="Leon", py_modules=["War_of_Tank.War_of_Tank", "War_of_Tank.toel"])
